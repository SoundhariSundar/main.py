import pymongo
from flask import Flask,render_template,request
app=Flask(__name__)
con= pymongo.MongoClient()
db=con['registration_page']
coll=db['submit']
app=Flask('registration_page')
@app.route('/')
def home():
    return render_template("front_page.html")
@app.route("/submit", methods=["GET", "POST"])
def submit():
    name = request.form.get('name')
    email = request.form.get('email')
    dob = request.form.get('dob')
    age= request.form.get('age')
    gender=request.form.get('gender')
    address=request.form.get('address')
    education=request.form.get('edu')
    number=request.form.get('number')
    agreement=request.form.get('check')
    try:
        coll.insert_one({"Name": name,
                     "Email": email,
                     "Date of birth": dob,
                     "age":age,
                     "gender": gender,
                     "address": address,
                     "edu": education,
                     "number": number,
                     "agreement": agreement
                     })
        return render_template("submit.html")
    except:
        return "Not inserted"
app.run(debug=True)